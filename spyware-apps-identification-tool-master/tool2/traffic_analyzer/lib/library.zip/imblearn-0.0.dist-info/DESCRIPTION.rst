Use `imbalanced-learn <https://pypi.python.org/pypi/imbalanced-learn/>`_ instead.


